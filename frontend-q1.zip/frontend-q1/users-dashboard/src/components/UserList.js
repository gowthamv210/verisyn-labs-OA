import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Box from "@mui/material/Box";
import styles from "./UserList.module.css";
import UserCard from "./UserCard";
import {
  Email as EmailIcon,
  Phone as PhoneIcon,
  Language as WebsiteIcon,
  LocationOn as AddressIcon,
  Business as CompanyIcon,
} from "@mui/icons-material";
import AlternateEmailRoundedIcon from "@mui/icons-material/AlternateEmailRounded";

export default function UserList({ users }) {
  const [isModalOpen, setModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  function handleModal(user = null) {
    setModalOpen((currentModal) => !currentModal);
    setSelectedUser(user);
  }

  return (
    <>
      <Box className={styles.userList}>
        {users.map((user) => (
          <UserCard key={user.id} user={user} handleModal={handleModal} />
        ))}
      </Box>

      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            className={styles.backdrop}
            onClick={() => handleModal(null)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className={styles.modal}
              onClick={(e) => e.stopPropagation()}
              initial={{ y: "100vh", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100vh", opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              <button
                className={styles.closeButton}
                onClick={() => handleModal(null)}
              >
                &times;
              </button>

              {selectedUser && (
                <div className={styles.userDetails}>
                  <h2>{selectedUser.name.toUpperCase()}</h2>

                  <div className={styles.detailRow}>
                    <AlternateEmailRoundedIcon className={styles.icon} />{" "}
                    <span>{selectedUser.username.toLowerCase()}</span>
                  </div>

                  <div className={styles.detailRow}>
                    <EmailIcon className={styles.icon} />
                    <span>
                      {" "}
                      <a
                        aria-label="mail"
                        target="_blank"
                        rel="noopener noreferrer"
                        href={`mailto:${selectedUser.email}`}
                        className={styles.emailLink}
                      >
                        {selectedUser.email}
                      </a>
                    </span>
                  </div>

                  <div className={styles.detailRow}>
                    <PhoneIcon className={styles.icon} />
                    <span>{selectedUser.phone.replace(/\./g, "-")}</span>
                  </div>

                  <div className={styles.detailRow}>
                    <WebsiteIcon className={styles.icon} />
                    <span>
                      {" "}
                      <a
                        href={`https://${selectedUser.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={styles.websiteLink}
                      >
                        {selectedUser.website}
                      </a>
                    </span>
                  </div>

                  <div className={styles.detailRow}>
                    <AddressIcon className={styles.icon} />
                    <span>
                      {selectedUser.address.street},{" "}
                      {selectedUser.address.suite}, {selectedUser.address.city},{" "}
                      {selectedUser.address.zipcode}
                    </span>
                  </div>

                  <div className={styles.detailRow}>
                    <CompanyIcon className={styles.icon} />
                    <span>
                      {selectedUser.company.name} - (
                      {selectedUser.company.catchPhrase}
                    </span>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
